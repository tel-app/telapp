# TelApp – TikTok-style short video app

## Quick start

```bash
cd TELAPP
pip install -r requirements.txt
python com2.py
```

Open http://127.0.0.1:5000

## Features

### Core
- Auth (register / login with username, email or phone)
- Vertical video feed with like / comment / share
- Follow system
- Direct messages (real-time Socket.IO)
- Profile + avatar upload

### New features added
| Feature | Description |
|---------|-------------|
| **Watermark** | "TelApp" overlay on every video in the feed |
| **Search bar** | Search users by username / bio |
| **Blue tick** | Auto-verified badge when user reaches **500 followers** |
| **LIVE** | Go Live unlocked at **500 followers** |
| **Privacy account** | Toggle private account; follow requests required |
| **Follow requests** | Accept / reject pending follows |
| **Tags** | `#hashtags` and `@mentions` highlighted in captions |
| **Filters** | CSS filters: vintage, cool, warm, bw, vivid, cinema |
| **Record & edit** | In-app camera recording (max 60s) via MediaRecorder |
| **Content limits** | Max **60 seconds** per video, **20 posts/day** |
| **Extract sound** | Download audio from any video (no picture) via ffmpeg |
| **Invite friend** | Unique invite code; invitee auto-follows you |
| **You May Know** | Suggested users based on network |
| **Audio / video call** | WebRTC signaling via Socket.IO |
| **Rate** | Rate the app (1–5 stars + review) |
| **Help** | In-app help panel listing all features |
| **Group account** | Create shared group profiles |
| **Movable inbox** | Chat panel CSS ready for drag |
| **Premium (Stripe)** | Monthly/Yearly plans; payments go to **your** Stripe account |

## Security notes
- Socket events use authenticated session only
- Timezone-aware UTC timestamps
- Session cookies: HttpOnly + SameSite
- Race-condition handling on likes / follows

## Notes
- Set `SECRET_KEY` env var in production
- ffmpeg required for audio extraction
- Twilio / OTP table exists but is not fully wired yet

## Stripe Premium setup

Pesa zinaingia **Stripe account yako**. Weka keys kwenye `.env` au environment:

```bash
export STRIPE_SECRET_KEY=sk_live_...          # au sk_test_...
export STRIPE_PUBLISHABLE_KEY=pk_live_...
export STRIPE_WEBHOOK_SECRET=whsec_...        # optional but recommended
export APP_BASE_URL=https://your-domain.com   # production URL

# Optional: Price IDs from Stripe Dashboard (Products → Prices)
# Kama hazijawekwa, app hutumia price_data moja kwa moja ($4.99/mo, $39.99/yr)
export STRIPE_PRICE_MONTHLY=price_...
export STRIPE_PRICE_YEARLY=price_...
```

Webhook endpoint (Stripe Dashboard → Developers → Webhooks):

```
POST https://your-domain.com/api/premium/webhook
```

Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`

### Premium benefits
- Hakuna watermark
- Video hadi 180s (badala ya 60s)
- 50 posts/siku (badala ya 20)
- LIVE bila kufikia 500 followers
- Crown badge


## Account settings update

The account settings modal now supports editing the username and bio, choosing a profile picture, removing a locally uploaded profile picture, setting account privacy, viewing follow requests, and logging out. Profile images are limited to 5 MB in the UI and accepted image formats are JPEG, PNG, WEBP, and GIF.

### Important backend note

This project version still uses its existing Flask session and SQLite database (`app.db`) for these routes. The account settings changes do **not** automatically migrate existing users or media to Supabase. Supabase tables must be populated by an explicit Auth/Storage integration before they will show records. Do not assume a successful Flask response means a Supabase write occurred.

### Profile picture deletion

`POST /api/profile/avatar/delete` requires a logged-in session. It clears the user's avatar and only attempts to delete an uploaded local file whose filename matches the current user's avatar prefix. Remote avatar URLs are not deleted.
