import os
import uuid
import sqlite3
import json
import re
import subprocess
from datetime import datetime, timezone, timedelta

from flask import (
    Flask,
    request,
    jsonify,
    session,
    render_template,
    send_from_directory
)
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from dotenv import load_dotenv

try:
    import stripe
except ImportError:
    stripe = None

# ============================================================
# CONFIGURATION
# ============================================================

load_dotenv()

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, "app.db")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__, template_folder="templates")
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY") or "TELAPP_DEV_ONLY_CHANGE_ME_IN_PRODUCTION"
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"

CORS(app, supports_credentials=True, origins=["*"])
socketio = SocketIO(app, cors_allowed_origins="*", async_mode="threading")

# Feature constants
FOLLOWERS_FOR_LIVE = 500
FOLLOWERS_FOR_BLUE_TICK = 500
MAX_VIDEO_SECONDS = 60
MAX_DAILY_POSTS = 20
MAX_VIDEO_SECONDS_PREMIUM = 180
MAX_DAILY_POSTS_PREMIUM = 50
WATERMARK_TEXT = "TelApp"

# Stripe (money goes to YOUR Stripe account via these keys)
STRIPE_SECRET_KEY = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_PUBLISHABLE_KEY = os.getenv("STRIPE_PUBLISHABLE_KEY", "")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")
# Optional: Price IDs from Stripe Dashboard (Products → Prices). If empty, Checkout uses price_data.
STRIPE_PRICE_MONTHLY = os.getenv("STRIPE_PRICE_MONTHLY", "")
STRIPE_PRICE_YEARLY = os.getenv("STRIPE_PRICE_YEARLY", "")
APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:5000")

if stripe and STRIPE_SECRET_KEY:
    stripe.api_key = STRIPE_SECRET_KEY

# Premium plan catalog (amounts in cents USD)
PREMIUM_PLANS = {
    "monthly": {
        "id": "monthly",
        "name": "Premium Monthly",
        "name_sw": "Premium Kila Mwezi",
        "price_cents": 499,
        "currency": "usd",
        "interval": "month",
        "description": "No watermark • 180s videos • 50 posts/day • LIVE unlock • Premium badge",
        "description_sw": "Hakuna watermark • Video 180s • 50 posts/siku • LIVE • Badge ya Premium",
    },
    "yearly": {
        "id": "yearly",
        "name": "Premium Yearly",
        "name_sw": "Premium Kila Mwaka",
        "price_cents": 3999,
        "currency": "usd",
        "interval": "year",
        "description": "Save ~33% • All Premium benefits for 12 months",
        "description_sw": "Okoa ~33% • Faida zote za Premium kwa miezi 12",
    },
}

# ============================================================
# DATABASE
# ============================================================

def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON;")
    db.execute("PRAGMA journal_mode = WAL;")
    return db


def init_database():
    db = get_db()
    db.executescript("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE,
        phone TEXT UNIQUE,
        password TEXT NOT NULL,
        avatar TEXT DEFAULT '',
        bio TEXT DEFAULT '',
        phone_verified INTEGER DEFAULT 0,
        is_verified INTEGER DEFAULT 0,
        is_private INTEGER DEFAULT 0,
        is_group INTEGER DEFAULT 0,
        invite_code TEXT DEFAULT '',
        created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS videos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        video_url TEXT NOT NULL,
        caption TEXT DEFAULT '',
        audio_track TEXT DEFAULT '',
        tags TEXT DEFAULT '',
        filter_name TEXT DEFAULT 'none',
        likes INTEGER DEFAULT 0,
        shares INTEGER DEFAULT 0,
        views INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        video_id INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        UNIQUE(user_id, video_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS comments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        video_id INTEGER NOT NULL,
        text TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(video_id) REFERENCES videos(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS follows (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_id INTEGER NOT NULL,
        target_user_id INTEGER NOT NULL,
        status TEXT DEFAULT 'accepted',
        UNIQUE(follower_id, target_user_id),
        FOREIGN KEY(follower_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(target_user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS direct_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id INTEGER NOT NULL,
        receiver_id INTEGER NOT NULL,
        message TEXT NOT NULL,
        msg_type TEXT DEFAULT 'text',
        created_at TEXT NOT NULL,
        FOREIGN KEY(sender_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(receiver_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS otp_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        phone TEXT NOT NULL,
        code TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        verified INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS ratings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        target_type TEXT NOT NULL,
        target_id INTEGER NOT NULL,
        score INTEGER NOT NULL,
        review TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        UNIQUE(user_id, target_type, target_id),
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS group_members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        role TEXT DEFAULT 'member',
        UNIQUE(group_id, user_id),
        FOREIGN KEY(group_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS live_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT DEFAULT '',
        status TEXT DEFAULT 'live',
        viewer_count INTEGER DEFAULT 0,
        started_at TEXT NOT NULL,
        ended_at TEXT,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS call_signals (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        caller_id INTEGER NOT NULL,
        callee_id INTEGER NOT NULL,
        call_type TEXT DEFAULT 'audio',
        signal_data TEXT,
        status TEXT DEFAULT 'ringing',
        created_at TEXT NOT NULL,
        FOREIGN KEY(caller_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY(callee_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        plan_id TEXT NOT NULL,
        stripe_customer_id TEXT DEFAULT '',
        stripe_subscription_id TEXT DEFAULT '',
        stripe_session_id TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        current_period_end TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
    );
    """)
    # Migrations for existing DBs
    migrations = [
        "ALTER TABLE users ADD COLUMN is_verified INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN is_private INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN is_group INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN invite_code TEXT DEFAULT ''",
        "ALTER TABLE users ADD COLUMN is_premium INTEGER DEFAULT 0",
        "ALTER TABLE users ADD COLUMN premium_until TEXT DEFAULT ''",
        "ALTER TABLE users ADD COLUMN stripe_customer_id TEXT DEFAULT ''",

        "ALTER TABLE videos ADD COLUMN tags TEXT DEFAULT ''",
        "ALTER TABLE videos ADD COLUMN filter_name TEXT DEFAULT 'none'",
        "ALTER TABLE videos ADD COLUMN views INTEGER DEFAULT 0",
        "ALTER TABLE follows ADD COLUMN status TEXT DEFAULT 'accepted'",
        "ALTER TABLE direct_messages ADD COLUMN msg_type TEXT DEFAULT 'text'",
    ]
    for m in migrations:
        try:
            db.execute(m)
        except sqlite3.OperationalError:
            pass
    db.commit()
    db.close()


init_database()

# ============================================================
# HELPERS
# ============================================================

ALLOWED_VIDEO_EXTENSIONS = {"mp4", "mov", "avi", "mkv", "webm"}
ALLOWED_IMAGE_EXTENSIONS = {"jpg", "jpeg", "png", "gif", "webp"}


def now():
    return datetime.now(timezone.utc).isoformat()


def allowed_video(filename):
    if not filename or "." not in filename:
        return False
    return filename.rsplit(".", 1)[1].lower() in ALLOWED_VIDEO_EXTENSIONS


def get_current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    db.close()
    return user


def is_user_premium(user):
    """True if user has active premium (flag + not expired)."""
    if not user:
        return False
    # support both Row and dict
    try:
        flag = user["is_premium"] if "is_premium" in user.keys() else 0
        until = user["premium_until"] if "premium_until" in user.keys() else ""
    except Exception:
        flag = getattr(user, "is_premium", 0) or 0
        until = getattr(user, "premium_until", "") or ""
    if not flag:
        return False
    if not until:
        return True
    try:
        end = datetime.fromisoformat(until.replace("Z", "+00:00"))
        if end.tzinfo is None:
            end = end.replace(tzinfo=timezone.utc)
        return end > datetime.now(timezone.utc)
    except Exception:
        return bool(flag)


def user_dict(user):
    if not user:
        return None
    db = get_db()
    followers = db.execute(
        "SELECT COUNT(*) as c FROM follows WHERE target_user_id = ? AND status = 'accepted'",
        (user["id"],)
    ).fetchone()["c"]
    # Auto blue-tick at threshold
    is_verified = bool(user["is_verified"]) or followers >= FOLLOWERS_FOR_BLUE_TICK
    if is_verified and not user["is_verified"]:
        try:
            db.execute("UPDATE users SET is_verified = 1 WHERE id = ?", (user["id"],))
            db.commit()
        except Exception:
            pass
    premium = is_user_premium(user)
    # Premium users can go live without follower threshold
    can_live = followers >= FOLLOWERS_FOR_LIVE or is_verified or premium
    try:
        premium_until = user["premium_until"] if "premium_until" in user.keys() else ""
    except Exception:
        premium_until = ""
    db.close()
    return {
        "id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "phone": user["phone"],
        "avatar": user["avatar"] or f"https://ui-avatars.com/api/?name={user['username']}&background=random&color=fff",
        "bio": user["bio"] or "",
        "phoneVerified": bool(user["phone_verified"]),
        "isVerified": is_verified,
        "isPrivate": bool(user["is_private"]),
        "isGroup": bool(user["is_group"]),
        "inviteCode": user["invite_code"] or "",
        "followersCount": followers,
        "canGoLive": can_live,
        "isPremium": premium,
        "premiumUntil": premium_until or None,
        "createdAt": user["created_at"]
    }


def require_login():
    return get_current_user()


def dm_room(user_a, user_b):
    a, b = sorted([str(user_a).lower(), str(user_b).lower()])
    return f"dm_{a}__{b}"


def extract_tags(caption):
    """Extract #hashtags and @mentions from caption."""
    tags = re.findall(r"[#@][\w\u00C0-\u024F]+", caption or "")
    return ",".join(tags[:20])


def generate_invite_code():
    return uuid.uuid4().hex[:8].upper()


# ============================================================
# PAGES
# ============================================================

@app.route("/")
def index():
    return render_template("video.html")


@app.route("/video.html")
def video_page():
    return render_template("video.html")


# ============================================================
# AUTHENTICATION APIs
# ============================================================

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", "")).strip().lower()
    email = str(data.get("email", "")).strip()
    phone = str(data.get("phone", "")).strip()
    password = str(data.get("password", ""))
    invite = str(data.get("inviteCode", "")).strip().upper()

    if not username or not password:
        return jsonify({"success": False, "message": "Username and password required"}), 400
    if len(username) < 3:
        return jsonify({"success": False, "message": "Username must be at least 3 characters"}), 400
    if len(password) < 6:
        return jsonify({"success": False, "message": "Password must be at least 6 characters"}), 400

    db = get_db()
    existing = db.execute(
        "SELECT id FROM users WHERE username = ? OR (? != '' AND email = ?) OR (? != '' AND phone = ?)",
        (username, email, email, phone, phone)
    ).fetchone()

    if existing:
        db.close()
        return jsonify({"success": False, "message": "Username, email or phone already exists"}), 409

    hashed = generate_password_hash(password)
    avatar = f"https://ui-avatars.com/api/?name={username}&background=random&color=fff"
    code = generate_invite_code()

    cursor = db.execute(
        "INSERT INTO users (username, email, phone, password, avatar, invite_code, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (username, email or None, phone or None, hashed, avatar, code, now())
    )
    db.commit()
    user_id = cursor.lastrowid

    # If invited by someone, auto-follow them (accepted)
    if invite:
        inviter = db.execute("SELECT id FROM users WHERE invite_code = ?", (invite,)).fetchone()
        if inviter and inviter["id"] != user_id:
            try:
                db.execute(
                    "INSERT INTO follows (follower_id, target_user_id, status) VALUES (?, ?, 'accepted')",
                    (user_id, inviter["id"])
                )
                db.commit()
            except sqlite3.IntegrityError:
                pass

    user = db.execute("SELECT * FROM users WHERE id = ?", (user_id,)).fetchone()
    db.close()

    session["user_id"] = user_id
    return jsonify({"success": True, "message": "Account created", "user": user_dict(user)}), 201


@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    identity = str(data.get("username", "")).strip().lower()
    password = str(data.get("password", ""))

    if not identity or not password:
        return jsonify({"success": False, "message": "Username and password required"}), 400

    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE lower(username) = ? OR lower(COALESCE(email,'')) = ? OR phone = ?",
        (identity, identity, identity)
    ).fetchone()
    db.close()

    if not user or not check_password_hash(user["password"], password):
        return jsonify({"success": False, "message": "Invalid login details"}), 401

    session["user_id"] = user["id"]
    return jsonify({"success": True, "message": "Login successful", "user": user_dict(user)})


@app.route("/api/auth", methods=["POST"])
def auth_unified():
    data = request.get_json(silent=True) or {}
    if data.get("isSignUp"):
        return register()
    return login()


@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"success": True, "message": "Logged out"})


@app.route("/api/me", methods=["GET"])
def me():
    user = get_current_user()
    if not user:
        return jsonify({"success": False, "message": "Not logged in"}), 401
    return jsonify({"success": True, "user": user_dict(user)})


# ============================================================
# USERS & SEARCH
# ============================================================

@app.route("/api/users/search", methods=["GET"])
def search_users():
    q = request.args.get("q", "").strip().lower()
    if not q or len(q) < 1:
        return jsonify([])

    db = get_db()
    rows = db.execute(
        """
        SELECT id, username, avatar, bio, is_verified, is_private,
               (SELECT COUNT(*) FROM follows WHERE target_user_id = users.id AND status = 'accepted') as followers_count
        FROM users
        WHERE lower(username) LIKE ? OR lower(COALESCE(bio,'')) LIKE ?
        ORDER BY followers_count DESC, username
        LIMIT 20
        """,
        (f"%{q}%", f"%{q}%")
    ).fetchall()
    db.close()

    return jsonify([
        {
            "id": r["id"],
            "username": r["username"],
            "avatar": r["avatar"] or f"https://ui-avatars.com/api/?name={r['username']}&background=random&color=fff",
            "bio": r["bio"] or "",
            "isVerified": bool(r["is_verified"]) or r["followers_count"] >= FOLLOWERS_FOR_BLUE_TICK,
            "isPrivate": bool(r["is_private"]),
            "followers_count": r["followers_count"]
        }
        for r in rows
    ])


@app.route("/api/users/<username>", methods=["GET"])
def get_user_by_username(username):
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE lower(username) = ?", (username.lower(),)).fetchone()
    if not user:
        db.close()
        return jsonify({"success": False, "message": "User not found"}), 404

    followers = db.execute(
        "SELECT COUNT(*) as c FROM follows WHERE target_user_id = ? AND status = 'accepted'", (user["id"],)
    ).fetchone()["c"]
    following = db.execute(
        "SELECT COUNT(*) as c FROM follows WHERE follower_id = ? AND status = 'accepted'", (user["id"],)
    ).fetchone()["c"]
    videos = db.execute(
        "SELECT id, video_url, caption, likes, shares, tags, filter_name, created_at FROM videos WHERE user_id = ? ORDER BY created_at DESC",
        (user["id"],)
    ).fetchall()
    total_likes = db.execute(
        "SELECT COALESCE(SUM(likes),0) as t FROM videos WHERE user_id = ?", (user["id"],)
    ).fetchone()["t"]
    db.close()

    is_verified = bool(user["is_verified"]) or followers >= FOLLOWERS_FOR_BLUE_TICK
    return jsonify({
        "success": True,
        "user": {
            **user_dict(user),
            "followersCount": followers,
            "followingCount": following,
            "likesCount": total_likes,
            "isVerified": is_verified,
            "canGoLive": followers >= FOLLOWERS_FOR_LIVE or is_verified or is_user_premium(user),
            "posts": [
                {
                    "id": v["id"],
                    "videoUrl": v["video_url"],
                    "caption": v["caption"],
                    "likes": v["likes"],
                    "shares": v["shares"],
                    "tags": v["tags"] or "",
                    "filter": v["filter_name"] or "none",
                    "createdAt": v["created_at"]
                }
                for v in videos
            ]
        }
    })


@app.route("/api/users/suggestions", methods=["GET"])
def you_may_know():
    """Suggested users (You May Know) based on mutual connections or popular."""
    user = get_current_user()
    db = get_db()
    current_id = user["id"] if user else 0

    # Prefer users followed by people you follow, exclude already following / self
    rows = db.execute("""
        SELECT u.id, u.username, u.avatar, u.bio, u.is_verified,
               (SELECT COUNT(*) FROM follows WHERE target_user_id = u.id AND status = 'accepted') as followers_count
        FROM users u
        WHERE u.id != ?
          AND u.id NOT IN (SELECT target_user_id FROM follows WHERE follower_id = ?)
          AND (u.is_private = 0 OR u.id IN (
              SELECT f2.target_user_id FROM follows f1
              JOIN follows f2 ON f1.target_user_id = f2.follower_id
              WHERE f1.follower_id = ? AND f1.status = 'accepted' AND f2.status = 'accepted'
          ))
        ORDER BY followers_count DESC
        LIMIT 15
    """, (current_id, current_id, current_id)).fetchall()
    db.close()

    return jsonify([
        {
            "id": r["id"],
            "username": r["username"],
            "avatar": r["avatar"] or f"https://ui-avatars.com/api/?name={r['username']}&background=random&color=fff",
            "bio": r["bio"] or "",
            "isVerified": bool(r["is_verified"]) or r["followers_count"] >= FOLLOWERS_FOR_BLUE_TICK,
            "followers_count": r["followers_count"]
        }
        for r in rows
    ])


# ============================================================
# FOLLOW SYSTEM + REQUESTS (for private accounts)
# ============================================================

@app.route("/api/follow/check", methods=["POST"])
def follow_check():
    data = request.get_json(silent=True) or {}
    user_a = data.get("userA")
    user_b = data.get("userB")
    if not user_a or not user_b:
        return jsonify({"isMutual": False, "aFollowsB": False, "bFollowsA": False, "status": None})

    db = get_db()
    a_follows_b = db.execute(
        "SELECT id, status FROM follows WHERE follower_id = ? AND target_user_id = ?",
        (user_a, user_b)
    ).fetchone()
    b_follows_a = db.execute(
        "SELECT id, status FROM follows WHERE follower_id = ? AND target_user_id = ?",
        (user_b, user_a)
    ).fetchone()
    db.close()

    return jsonify({
        "aFollowsB": bool(a_follows_b and a_follows_b["status"] == "accepted"),
        "bFollowsA": bool(b_follows_a and b_follows_a["status"] == "accepted"),
        "isMutual": bool(a_follows_b and a_follows_b["status"] == "accepted" and b_follows_a and b_follows_a["status"] == "accepted"),
        "status": a_follows_b["status"] if a_follows_b else None
    })


@app.route("/api/follow/toggle", methods=["POST"])
def follow_toggle():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    target_id = data.get("targetUserId")
    if not target_id or target_id == user["id"]:
        return jsonify({"success": False, "message": "Invalid target"}), 400

    db = get_db()
    target = db.execute("SELECT * FROM users WHERE id = ?", (target_id,)).fetchone()
    if not target:
        db.close()
        return jsonify({"success": False, "message": "User not found"}), 404

    existing = db.execute(
        "SELECT id, status FROM follows WHERE follower_id = ? AND target_user_id = ?",
        (user["id"], target_id)
    ).fetchone()

    if existing:
        db.execute("DELETE FROM follows WHERE id = ?", (existing["id"],))
        is_following = False
        status = None
    else:
        # Private account → request
        status = "pending" if target["is_private"] else "accepted"
        db.execute(
            "INSERT INTO follows (follower_id, target_user_id, status) VALUES (?, ?, ?)",
            (user["id"], target_id, status)
        )
        is_following = status == "accepted"
    db.commit()
    db.close()

    return jsonify({"success": True, "isFollowing": is_following, "status": status})


@app.route("/api/follow/requests", methods=["GET"])
def get_follow_requests():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    rows = db.execute("""
        SELECT f.id as request_id, u.id, u.username, u.avatar, u.bio, f.status
        FROM follows f
        JOIN users u ON u.id = f.follower_id
        WHERE f.target_user_id = ? AND f.status = 'pending'
        ORDER BY f.id DESC
    """, (user["id"],)).fetchall()
    db.close()

    return jsonify([
        {
            "requestId": r["request_id"],
            "id": r["id"],
            "username": r["username"],
            "avatar": r["avatar"] or f"https://ui-avatars.com/api/?name={r['username']}&background=random&color=fff",
            "bio": r["bio"] or ""
        }
        for r in rows
    ])


@app.route("/api/follow/requests/<int:request_id>", methods=["POST"])
def handle_follow_request(request_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    action = data.get("action", "accept")  # accept | reject

    db = get_db()
    req = db.execute(
        "SELECT * FROM follows WHERE id = ? AND target_user_id = ? AND status = 'pending'",
        (request_id, user["id"])
    ).fetchone()
    if not req:
        db.close()
        return jsonify({"success": False, "message": "Request not found"}), 404

    if action == "accept":
        db.execute("UPDATE follows SET status = 'accepted' WHERE id = ?", (request_id,))
        # Check blue tick for the follower target (us)
        followers = db.execute(
            "SELECT COUNT(*) as c FROM follows WHERE target_user_id = ? AND status = 'accepted'",
            (user["id"],)
        ).fetchone()["c"]
        if followers >= FOLLOWERS_FOR_BLUE_TICK:
            db.execute("UPDATE users SET is_verified = 1 WHERE id = ?", (user["id"],))
    else:
        db.execute("DELETE FROM follows WHERE id = ?", (request_id,))
    db.commit()
    db.close()
    return jsonify({"success": True, "action": action})


# ============================================================
# VIDEOS APIs
# ============================================================

@app.route("/api/videos", methods=["POST"])
def upload_video():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    # Daily post limit (higher for Premium)
    db = get_db()
    premium = is_user_premium(user)
    max_posts = MAX_DAILY_POSTS_PREMIUM if premium else MAX_DAILY_POSTS
    max_secs = MAX_VIDEO_SECONDS_PREMIUM if premium else MAX_VIDEO_SECONDS
    today_start = (datetime.now(timezone.utc) - timedelta(hours=24)).isoformat()
    daily_count = db.execute(
        "SELECT COUNT(*) as c FROM videos WHERE user_id = ? AND created_at >= ?",
        (user["id"], today_start)
    ).fetchone()["c"]
    if daily_count >= max_posts:
        db.close()
        return jsonify({"success": False, "message": f"Daily limit reached ({max_posts} videos/day)"}), 429

    video = request.files.get("videoFile") or request.files.get("video")
    if not video or not video.filename or not allowed_video(video.filename):
        db.close()
        return jsonify({"success": False, "message": "Invalid or missing video format"}), 400

    extension = video.filename.rsplit(".", 1)[1].lower()
    filename = secure_filename(f"{uuid.uuid4().hex}.{extension}")
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    video.save(filepath)

    # Optional duration limit check via ffprobe
    try:
        probe = subprocess.run(
            ["ffprobe", "-v", "error", "-show_entries", "format=duration",
             "-of", "default=noprint_wrappers=1:nokey=1", filepath],
            capture_output=True, text=True, timeout=10
        )
        if probe.returncode == 0 and probe.stdout.strip():
            duration = float(probe.stdout.strip())
            if duration > max_secs + 5:
                os.remove(filepath)
                db.close()
                return jsonify({"success": False, "message": f"Video too long (max {max_secs}s)"}), 400
    except Exception:
        pass

    caption = str(request.form.get("caption", "")).strip()
    audio_track = str(request.form.get("audioTrack", f"Original - @{user['username']}")).strip()
    filter_name = str(request.form.get("filter", "none")).strip() or "none"
    tags = extract_tags(caption)

    cursor = db.execute(
        "INSERT INTO videos (user_id, video_url, caption, audio_track, tags, filter_name, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (user["id"], f"/uploads/{filename}", caption, audio_track, tags, filter_name, now())
    )
    db.commit()
    video_id = cursor.lastrowid
    db.close()

    new_video = {
        "id": video_id,
        "user_id": user["id"],
        "username": user["username"],
        "avatar": user["avatar"],
        "isVerified": user_dict(user)["isVerified"],
        "videoUrl": f"/uploads/{filename}",
        "caption": caption,
        "audioTrack": audio_track,
        "tags": tags,
        "filter": filter_name,
        "likes": 0,
        "shares": 0,
        "commentsCount": 0,
        "isLiked": False,
        "createdAt": now()
    }

    socketio.emit("new_video_broadcast", new_video)
    return jsonify({"success": True, "message": "Video posted successfully", "video": new_video}), 201


@app.route("/api/videos", methods=["GET"])
def get_videos():
    user = get_current_user()
    current_user_id = user["id"] if user else 0

    db = get_db()
    # Respect private accounts: only show public or followed
    rows = db.execute("""
        SELECT v.*, u.username, u.avatar, u.is_verified, u.is_private, u.is_premium, u.premium_until,
        (SELECT COUNT(*) FROM comments c WHERE c.video_id = v.id) as commentsCount,
        (SELECT COUNT(*) FROM follows WHERE target_user_id = u.id AND status = 'accepted') as followers_count
        FROM videos v
        JOIN users u ON u.id = v.user_id
        WHERE u.is_private = 0
           OR u.id = ?
           OR EXISTS (
               SELECT 1 FROM follows f
               WHERE f.follower_id = ? AND f.target_user_id = u.id AND f.status = 'accepted'
           )
        ORDER BY v.created_at DESC
        LIMIT 50
    """, (current_user_id, current_user_id)).fetchall()

    videos = []
    for row in rows:
        liked = db.execute(
            "SELECT id FROM likes WHERE user_id = ? AND video_id = ?",
            (current_user_id, row["id"])
        ).fetchone()
        is_verified = bool(row["is_verified"]) or row["followers_count"] >= FOLLOWERS_FOR_BLUE_TICK
        # premium check for feed badge / watermark skip on client
        try:
            prem_flag = row["is_premium"]
            prem_until = row["premium_until"]
        except Exception:
            prem_flag, prem_until = 0, ""
        is_prem = bool(prem_flag)
        if is_prem and prem_until:
            try:
                end = datetime.fromisoformat(str(prem_until).replace("Z", "+00:00"))
                if end.tzinfo is None:
                    end = end.replace(tzinfo=timezone.utc)
                is_prem = end > datetime.now(timezone.utc)
            except Exception:
                pass
        videos.append({
            "id": row["id"],
            "user_id": row["user_id"],
            "username": row["username"],
            "avatar": row["avatar"] or f"https://ui-avatars.com/api/?name={row['username']}&background=random&color=fff",
            "isVerified": is_verified,
            "isPremium": is_prem,
            "videoUrl": row["video_url"],
            "caption": row["caption"],
            "audioTrack": row["audio_track"],
            "tags": row["tags"] or "",
            "filter": row["filter_name"] or "none",
            "likes": row["likes"],
            "shares": row["shares"],
            "views": row["views"] or 0,
            "commentsCount": row["commentsCount"],
            "isLiked": bool(liked),
            "createdAt": row["created_at"]
        })
    db.close()
    return jsonify(videos)


@app.route("/api/videos/<int:video_id>", methods=["DELETE"])
def delete_video(video_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    video = db.execute("SELECT * FROM videos WHERE id = ?", (video_id,)).fetchone()
    if not video:
        db.close()
        return jsonify({"success": False, "message": "Video not found"}), 404
    if video["user_id"] != user["id"]:
        db.close()
        return jsonify({"success": False, "message": "Unauthorized"}), 403

    try:
        path = os.path.join(BASE_DIR, video["video_url"].lstrip("/"))
        if os.path.isfile(path):
            os.remove(path)
    except Exception:
        pass

    db.execute("DELETE FROM videos WHERE id = ?", (video_id,))
    db.commit()
    db.close()

    socketio.emit("video_deleted", {"videoId": video_id})
    return jsonify({"success": True, "message": "Video deleted"})


@app.route("/api/videos/<int:video_id>/like", methods=["POST"])
def toggle_like_rest(video_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    video = db.execute("SELECT id, likes FROM videos WHERE id = ?", (video_id,)).fetchone()
    if not video:
        db.close()
        return jsonify({"success": False, "message": "Video not found"}), 404

    try:
        existing = db.execute(
            "SELECT id FROM likes WHERE user_id = ? AND video_id = ?",
            (user["id"], video_id)
        ).fetchone()
        if existing:
            db.execute("DELETE FROM likes WHERE id = ?", (existing["id"],))
            db.execute("UPDATE videos SET likes = MAX(0, likes - 1) WHERE id = ?", (video_id,))
            is_liked = False
        else:
            db.execute(
                "INSERT INTO likes (user_id, video_id, created_at) VALUES (?, ?, ?)",
                (user["id"], video_id, now())
            )
            db.execute("UPDATE videos SET likes = likes + 1 WHERE id = ?", (video_id,))
            is_liked = True
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        existing = db.execute(
            "SELECT id FROM likes WHERE user_id = ? AND video_id = ?",
            (user["id"], video_id)
        ).fetchone()
        is_liked = bool(existing)
        db.commit()

    row = db.execute("SELECT likes FROM videos WHERE id = ?", (video_id,)).fetchone()
    likes = row["likes"] if row else 0
    db.close()

    socketio.emit("update_like_count", {
        "videoId": video_id,
        "likes": likes,
        "isLiked": is_liked,
        "userId": user["id"]
    })
    return jsonify({"success": True, "isLiked": is_liked, "likes": likes})


@app.route("/api/videos/<int:video_id>/comments", methods=["POST"])
def post_comment_rest(video_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    text = str(data.get("text", "")).strip()
    if not text:
        return jsonify({"success": False, "message": "Comment text required"}), 400

    db = get_db()
    video = db.execute("SELECT id FROM videos WHERE id = ?", (video_id,)).fetchone()
    if not video:
        db.close()
        return jsonify({"success": False, "message": "Video not found"}), 404

    cursor = db.execute(
        "INSERT INTO comments (user_id, video_id, text, created_at) VALUES (?, ?, ?, ?)",
        (user["id"], video_id, text, now())
    )
    db.commit()
    comment_id = cursor.lastrowid
    db.close()

    comment_obj = {
        "id": comment_id,
        "videoId": video_id,
        "username": user["username"],
        "avatar": user["avatar"] or f"https://ui-avatars.com/api/?name={user['username']}&background=random&color=fff",
        "text": text,
        "createdAt": now()
    }
    socketio.emit("new_comment_broadcast", comment_obj)
    return jsonify({"success": True, "comment": comment_obj}), 201


@app.route("/api/videos/<int:video_id>/comments", methods=["GET"])
def get_comments(video_id):
    db = get_db()
    rows = db.execute("""
        SELECT c.*, u.username, u.avatar
        FROM comments c
        JOIN users u ON u.id = c.user_id
        WHERE c.video_id = ?
        ORDER BY c.created_at DESC
        LIMIT 100
    """, (video_id,)).fetchall()
    db.close()

    return jsonify([
        {
            "id": r["id"],
            "videoId": r["video_id"],
            "username": r["username"],
            "avatar": r["avatar"] or f"https://ui-avatars.com/api/?name={r['username']}&background=random&color=fff",
            "text": r["text"],
            "createdAt": r["created_at"]
        }
        for r in rows
    ])


@app.route("/api/comments/<int:comment_id>", methods=["DELETE"])
def delete_comment(comment_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    comment = db.execute("SELECT * FROM comments WHERE id = ?", (comment_id,)).fetchone()
    if not comment:
        db.close()
        return jsonify({"success": False, "message": "Comment not found"}), 404
    if comment["user_id"] != user["id"]:
        db.close()
        return jsonify({"success": False, "message": "Unauthorized"}), 403

    db.execute("DELETE FROM comments WHERE id = ?", (comment_id,))
    db.commit()
    db.close()
    return jsonify({"success": True, "message": "Comment deleted"})


@app.route("/api/videos/<int:video_id>/audio", methods=["GET"])
def extract_audio(video_id):
    """Extract audio from a video (no picture) and return downloadable file."""
    db = get_db()
    video = db.execute("SELECT * FROM videos WHERE id = ?", (video_id,)).fetchone()
    db.close()
    if not video:
        return jsonify({"success": False, "message": "Video not found"}), 404

    video_path = os.path.join(BASE_DIR, video["video_url"].lstrip("/"))
    if not os.path.isfile(video_path):
        return jsonify({"success": False, "message": "Video file missing"}), 404

    audio_name = f"audio_{video_id}_{uuid.uuid4().hex[:6]}.mp3"
    audio_path = os.path.join(UPLOAD_FOLDER, audio_name)

    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", video_path, "-vn", "-acodec", "libmp3lame", "-q:a", "4", audio_path],
            capture_output=True, timeout=60, check=True
        )
    except Exception as e:
        return jsonify({"success": False, "message": f"Audio extraction failed: {str(e)}"}), 500

    return send_from_directory(UPLOAD_FOLDER, audio_name, as_attachment=True, download_name=f"sound_{video_id}.mp3")


@app.route("/uploads/<path:filename>")
def serve_upload(filename):
    path = os.path.join(UPLOAD_FOLDER, filename)
    if not os.path.isfile(path):
        return jsonify({"success": False, "message": "File not found"}), 404
    return send_from_directory(UPLOAD_FOLDER, filename)


@app.route("/favicon.ico")
def favicon():
    return ("", 204)


@app.errorhandler(404)
def not_found(e):
    if request.path.startswith("/api/"):
        return jsonify({"success": False, "message": "Not found"}), 404
    return (
        "<!doctype html><html><head><title>404</title></head>"
        "<body style='font-family:system-ui;background:#000;color:#fff;"
        "display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
        "<div style='text-align:center'>"
        "<h1>404</h1><p>Page not found.</p>"
        "<a href='/' style='color:#22d3ee'>Back to TelApp</a>"
        "</div></body></html>",
        404,
    )


# ============================================================
# PROFILE UPDATE + PRIVACY
# ============================================================

@app.route("/api/profile/update", methods=["POST"])
def update_profile():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    username = request.form.get("username", user["username"]).strip().lower()
    bio = request.form.get("bio", user["bio"] or "").strip()
    avatar_url = request.form.get("avatarUrl", user["avatar"])
    is_private = request.form.get("isPrivate")
    if is_private is not None:
        is_private = 1 if str(is_private).lower() in ("1", "true", "yes") else 0
    else:
        is_private = user["is_private"]

    if "avatarFile" in request.files:
        file = request.files["avatarFile"]
        if file.filename:
            ext = file.filename.rsplit(".", 1)[1].lower() if "." in file.filename else "jpg"
            if ext in ALLOWED_IMAGE_EXTENSIONS:
                filename = secure_filename(f"avatar_{user['id']}_{uuid.uuid4().hex[:6]}.{ext}")
                filepath = os.path.join(UPLOAD_FOLDER, filename)
                file.save(filepath)
                avatar_url = f"/uploads/{filename}"

    db = get_db()
    try:
        db.execute(
            "UPDATE users SET username = ?, avatar = ?, bio = ?, is_private = ? WHERE id = ?",
            (username, avatar_url, bio, is_private, user["id"])
        )
        db.commit()
    except sqlite3.IntegrityError:
        db.close()
        return jsonify({"success": False, "message": "Username already taken"}), 409

    updated = db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
    db.close()
    return jsonify({"success": True, "user": user_dict(updated)})


@app.route("/api/profile/avatar/delete", methods=["POST"])
def delete_profile_avatar():
    """Remove the signed-in user's uploaded avatar without touching other files."""
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Please sign in first."}), 401

    db = get_db()
    current = db.execute("SELECT avatar FROM users WHERE id = ?", (user["id"],)).fetchone()
    if not current:
        db.close()
        return jsonify({"success": False, "message": "Account not found."}), 404

    avatar = current["avatar"] or ""
    # Only delete a file if it is a local upload owned by this user.
    if avatar.startswith("/uploads/avatar_" + str(user["id"]) + "_"):
        filename = os.path.basename(avatar)
        filepath = os.path.abspath(os.path.join(UPLOAD_FOLDER, filename))
        if os.path.dirname(filepath) == os.path.abspath(UPLOAD_FOLDER) and os.path.isfile(filepath):
            try:
                os.remove(filepath)
            except OSError:
                app.logger.exception("Could not delete avatar file for user %s", user["id"])

    fallback = f"https://ui-avatars.com/api/?name={user['username']}&background=random&color=fff"
    db.execute("UPDATE users SET avatar = ? WHERE id = ?", (fallback, user["id"]))
    db.commit()
    updated = db.execute("SELECT * FROM users WHERE id = ?", (user["id"],)).fetchone()
    db.close()
    return jsonify({"success": True, "user": user_dict(updated)})


@app.route("/api/invite", methods=["GET"])
def get_invite():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401
    code = user["invite_code"]
    if not code:
        code = generate_invite_code()
        db = get_db()
        db.execute("UPDATE users SET invite_code = ? WHERE id = ?", (code, user["id"]))
        db.commit()
        db.close()
    return jsonify({
        "success": True,
        "inviteCode": code,
        "inviteLink": f"/?invite={code}",
        "message": f"Invite friends with code: {code}"
    })


# ============================================================
# RATINGS
# ============================================================

@app.route("/api/rate", methods=["POST"])
def rate_something():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    target_type = data.get("targetType", "app")  # app | video | user
    target_id = int(data.get("targetId", 0))
    score = int(data.get("score", 0))
    review = str(data.get("review", "")).strip()[:500]

    if score < 1 or score > 5:
        return jsonify({"success": False, "message": "Score must be 1-5"}), 400

    db = get_db()
    try:
        db.execute(
            "INSERT INTO ratings (user_id, target_type, target_id, score, review, created_at) VALUES (?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(user_id, target_type, target_id) DO UPDATE SET score = excluded.score, review = excluded.review, created_at = excluded.created_at",
            (user["id"], target_type, target_id, score, review, now())
        )
        db.commit()
    except Exception as e:
        db.close()
        return jsonify({"success": False, "message": str(e)}), 500
    db.close()
    return jsonify({"success": True, "message": "Thanks for rating!"})


@app.route("/api/rate/stats", methods=["GET"])
def rate_stats():
    target_type = request.args.get("targetType", "app")
    target_id = int(request.args.get("targetId", 0))
    db = get_db()
    row = db.execute(
        "SELECT AVG(score) as avg_score, COUNT(*) as count FROM ratings WHERE target_type = ? AND target_id = ?",
        (target_type, target_id)
    ).fetchone()
    db.close()
    return jsonify({
        "avgScore": round(row["avg_score"] or 0, 1),
        "count": row["count"] or 0
    })


# ============================================================
# GROUP ACCOUNTS
# ============================================================

@app.route("/api/groups/create", methods=["POST"])
def create_group():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip().lower().replace(" ", "_")
    if not name or len(name) < 3:
        return jsonify({"success": False, "message": "Group name too short"}), 400

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE username = ?", (name,)).fetchone()
    if existing:
        db.close()
        return jsonify({"success": False, "message": "Name taken"}), 409

    hashed = generate_password_hash(uuid.uuid4().hex)
    avatar = f"https://ui-avatars.com/api/?name={name}&background=0ea5e9&color=fff"
    cursor = db.execute(
        "INSERT INTO users (username, password, avatar, bio, is_group, invite_code, created_at) VALUES (?, ?, ?, ?, 1, ?, ?)",
        (name, hashed, avatar, data.get("bio", "Group account"), generate_invite_code(), now())
    )
    group_id = cursor.lastrowid
    db.execute(
        "INSERT INTO group_members (group_id, user_id, role) VALUES (?, ?, 'admin')",
        (group_id, user["id"])
    )
    db.commit()
    group = db.execute("SELECT * FROM users WHERE id = ?", (group_id,)).fetchone()
    db.close()
    return jsonify({"success": True, "group": user_dict(group)}), 201


@app.route("/api/groups/<int:group_id>/members", methods=["GET"])
def group_members(group_id):
    db = get_db()
    rows = db.execute("""
        SELECT u.id, u.username, u.avatar, gm.role
        FROM group_members gm
        JOIN users u ON u.id = gm.user_id
        WHERE gm.group_id = ?
    """, (group_id,)).fetchall()
    db.close()
    return jsonify([
        {"id": r["id"], "username": r["username"], "avatar": r["avatar"], "role": r["role"]}
        for r in rows
    ])


# ============================================================
# LIVE STREAMING (when followers >= 500)
# ============================================================

@app.route("/api/live/start", methods=["POST"])
def start_live():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    ud = user_dict(user)
    if not ud["canGoLive"]:
        return jsonify({
            "success": False,
            "message": f"Need {FOLLOWERS_FOR_LIVE} followers to go live (you have {ud['followersCount']})"
        }), 403

    data = request.get_json(silent=True) or {}
    title = str(data.get("title", f"Live by @{user['username']}")).strip()[:100]

    db = get_db()
    # End any previous live
    db.execute(
        "UPDATE live_sessions SET status = 'ended', ended_at = ? WHERE user_id = ? AND status = 'live'",
        (now(), user["id"])
    )
    cursor = db.execute(
        "INSERT INTO live_sessions (user_id, title, status, started_at) VALUES (?, ?, 'live', ?)",
        (user["id"], title, now())
    )
    live_id = cursor.lastrowid
    db.commit()
    db.close()

    payload = {
        "liveId": live_id,
        "userId": user["id"],
        "username": user["username"],
        "avatar": user["avatar"],
        "title": title,
        "isVerified": ud["isVerified"]
    }
    socketio.emit("live_started", payload)
    return jsonify({"success": True, "live": payload})


@app.route("/api/live/end", methods=["POST"])
def end_live():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    db.execute(
        "UPDATE live_sessions SET status = 'ended', ended_at = ? WHERE user_id = ? AND status = 'live'",
        (now(), user["id"])
    )
    db.commit()
    db.close()
    socketio.emit("live_ended", {"userId": user["id"]})
    return jsonify({"success": True})


@app.route("/api/live/active", methods=["GET"])
def active_lives():
    db = get_db()
    rows = db.execute("""
        SELECT ls.*, u.username, u.avatar, u.is_verified
        FROM live_sessions ls
        JOIN users u ON u.id = ls.user_id
        WHERE ls.status = 'live'
        ORDER BY ls.started_at DESC
        LIMIT 20
    """).fetchall()
    db.close()
    return jsonify([
        {
            "liveId": r["id"],
            "userId": r["user_id"],
            "username": r["username"],
            "avatar": r["avatar"],
            "title": r["title"],
            "viewerCount": r["viewer_count"],
            "isVerified": bool(r["is_verified"])
        }
        for r in rows
    ])


# ============================================================
# CALLS (audio / video signaling via Socket.IO)
# ============================================================

@app.route("/api/call/start", methods=["POST"])
def start_call():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    data = request.get_json(silent=True) or {}
    callee_username = str(data.get("username", "")).strip().lower()
    call_type = data.get("callType", "audio")  # audio | video

    db = get_db()
    callee = db.execute("SELECT * FROM users WHERE lower(username) = ?", (callee_username,)).fetchone()
    if not callee:
        db.close()
        return jsonify({"success": False, "message": "User not found"}), 404

    cursor = db.execute(
        "INSERT INTO call_signals (caller_id, callee_id, call_type, status, created_at) VALUES (?, ?, ?, 'ringing', ?)",
        (user["id"], callee["id"], call_type, now())
    )
    call_id = cursor.lastrowid
    db.commit()
    db.close()

    payload = {
        "callId": call_id,
        "callerId": user["id"],
        "callerUsername": user["username"],
        "callerAvatar": user["avatar"],
        "calleeId": callee["id"],
        "callType": call_type
    }
    socketio.emit("incoming_call", payload, room=f"user_{callee['username'].lower()}")
    return jsonify({"success": True, "call": payload})


# ============================================================
# DIRECT MESSAGES
# ============================================================

@app.route("/api/messages/<username>", methods=["GET"])
def get_messages(username):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    other = db.execute("SELECT * FROM users WHERE lower(username) = ?", (username.lower(),)).fetchone()
    if not other:
        db.close()
        return jsonify({"success": False, "message": "User not found"}), 404

    rows = db.execute("""
        SELECT m.*, s.username as sender_username, r.username as receiver_username
        FROM direct_messages m
        JOIN users s ON s.id = m.sender_id
        JOIN users r ON r.id = m.receiver_id
        WHERE (m.sender_id = ? AND m.receiver_id = ?) OR (m.sender_id = ? AND m.receiver_id = ?)
        ORDER BY m.created_at ASC
        LIMIT 200
    """, (user["id"], other["id"], other["id"], user["id"])).fetchall()
    db.close()

    return jsonify({
        "success": True,
        "otherUser": user_dict(other),
        "messages": [
            {
                "id": r["id"],
                "senderId": r["sender_id"],
                "receiverId": r["receiver_id"],
                "username": r["sender_username"],
                "text": r["message"],
                "msgType": r["msg_type"] if "msg_type" in r.keys() else "text",
                "time": r["created_at"],
                "isMine": r["sender_id"] == user["id"]
            }
            for r in rows
        ]
    })


@app.route("/api/messages/<int:msg_id>", methods=["DELETE"])
def delete_message(msg_id):
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    msg = db.execute("SELECT * FROM direct_messages WHERE id = ?", (msg_id,)).fetchone()
    if not msg:
        db.close()
        return jsonify({"success": False, "message": "Message not found"}), 404
    if msg["sender_id"] != user["id"]:
        db.close()
        return jsonify({"success": False, "message": "Unauthorized"}), 403

    db.execute("DELETE FROM direct_messages WHERE id = ?", (msg_id,))
    db.commit()
    db.close()
    socketio.emit("message_deleted", {"messageId": msg_id})
    return jsonify({"success": True, "message": "Message deleted"})


@app.route("/api/conversations", methods=["GET"])
def get_conversations():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401

    db = get_db()
    rows = db.execute("""
        SELECT 
            CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END as other_id,
            u.username, u.avatar, u.is_verified,
            m.message as last_message,
            m.created_at as last_time,
            m.sender_id as last_sender
        FROM direct_messages m
        JOIN users u ON u.id = CASE WHEN m.sender_id = ? THEN m.receiver_id ELSE m.sender_id END
        WHERE m.id IN (
            SELECT MAX(id) FROM direct_messages
            WHERE sender_id = ? OR receiver_id = ?
            GROUP BY CASE WHEN sender_id = ? THEN receiver_id ELSE sender_id END
        )
        ORDER BY m.created_at DESC
    """, (user["id"], user["id"], user["id"], user["id"], user["id"])).fetchall()
    db.close()

    return jsonify([
        {
            "id": r["other_id"],
            "username": r["username"],
            "avatar": r["avatar"] or f"https://ui-avatars.com/api/?name={r['username']}&background=random&color=fff",
            "isVerified": bool(r["is_verified"]),
            "lastMessage": r["last_message"],
            "lastTime": r["last_time"],
            "isMine": r["last_sender"] == user["id"]
        }
        for r in rows
    ])


# ============================================================
# SOCKET.IO REAL-TIME
# ============================================================

@socketio.on("connect")
def socket_connect():
    user = get_current_user()
    emit("connection_success", {
        "success": True,
        "username": user["username"] if user else None
    })


@socketio.on("join_user_room")
def join_user_room(data):
    username = data.get("username")
    if username:
        join_room(f"user_{username.lower()}")


@socketio.on("join_dm")
def join_dm(data):
    me = data.get("me")
    other = data.get("other")
    if me and other:
        room = dm_room(me, other)
        join_room(room)
        emit("joined_dm", {"room": room})


@socketio.on("send_direct_message")
def handle_direct_message(data):
    current = get_current_user()
    if not current:
        return
    receiver_username = data.get("receiverUsername") or data.get("receiver")
    text = (data.get("text") or "").strip()
    msg_type = data.get("msgType", "text")

    if not receiver_username or not text:
        return

    db = get_db()
    sender = current
    receiver = db.execute(
        "SELECT * FROM users WHERE lower(username) = ?",
        (str(receiver_username).lower(),)
    ).fetchone()

    if not receiver:
        db.close()
        return

    cursor = db.execute(
        "INSERT INTO direct_messages (sender_id, receiver_id, message, msg_type, created_at) VALUES (?, ?, ?, ?, ?)",
        (sender["id"], receiver["id"], text, msg_type, now())
    )
    db.commit()
    msg_id = cursor.lastrowid
    db.close()

    payload = {
        "id": msg_id,
        "senderId": sender["id"],
        "receiverId": receiver["id"],
        "username": sender["username"],
        "receiverUsername": receiver["username"],
        "text": text,
        "msgType": msg_type,
        "time": datetime.now(timezone.utc).strftime("%H:%M")
    }

    room = dm_room(sender["username"], receiver["username"])
    emit("receive_direct_message", payload, room=room, include_self=False)
    emit("new_dm_notification", payload, room=f"user_{receiver['username'].lower()}")


@socketio.on("toggle_like")
def socket_toggle_like(data):
    current = get_current_user()
    if not current:
        return
    user_id = current["id"]
    video_id = data.get("videoId")
    if not video_id:
        return

    db = get_db()
    try:
        existing = db.execute(
            "SELECT id FROM likes WHERE user_id = ? AND video_id = ?",
            (user_id, video_id)
        ).fetchone()

        if existing:
            db.execute("DELETE FROM likes WHERE id = ?", (existing["id"],))
            db.execute("UPDATE videos SET likes = MAX(0, likes - 1) WHERE id = ?", (video_id,))
            is_liked = False
        else:
            db.execute(
                "INSERT INTO likes (user_id, video_id, created_at) VALUES (?, ?, ?)",
                (user_id, video_id, now())
            )
            db.execute("UPDATE videos SET likes = likes + 1 WHERE id = ?", (video_id,))
            is_liked = True
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        existing = db.execute(
            "SELECT id FROM likes WHERE user_id = ? AND video_id = ?",
            (user_id, video_id)
        ).fetchone()
        is_liked = bool(existing)
        db.commit()

    row = db.execute("SELECT likes FROM videos WHERE id = ?", (video_id,)).fetchone()
    likes = row["likes"] if row else 0
    db.close()

    emit("update_like_count", {
        "videoId": video_id,
        "likes": likes,
        "isLiked": is_liked,
        "userId": user_id
    })


@socketio.on("send_comment")
def socket_send_comment(data):
    current = get_current_user()
    if not current:
        return
    video_id = data.get("videoId")
    text = (data.get("text") or "").strip()
    if not video_id or not text:
        return

    db = get_db()
    user = current

    cursor = db.execute(
        "INSERT INTO comments (user_id, video_id, text, created_at) VALUES (?, ?, ?, ?)",
        (user["id"], video_id, text, now())
    )
    db.commit()
    comment_id = cursor.lastrowid
    db.close()

    comment_obj = {
        "id": comment_id,
        "videoId": video_id,
        "username": user["username"],
        "avatar": user["avatar"] or f"https://ui-avatars.com/api/?name={user['username']}&background=random&color=fff",
        "text": text,
        "createdAt": now()
    }
    emit("new_comment_broadcast", comment_obj)


@socketio.on("share_video")
def socket_share_video(data):
    video_id = data.get("videoId")
    if not video_id:
        return
    db = get_db()
    db.execute("UPDATE videos SET shares = shares + 1 WHERE id = ?", (video_id,))
    db.commit()
    row = db.execute("SELECT shares FROM videos WHERE id = ?", (video_id,)).fetchone()
    shares = row["shares"] if row else 0
    db.close()
    emit("update_share_count", {"videoId": video_id, "shares": shares})


@socketio.on("toggle_follow")
def socket_toggle_follow(data):
    current = get_current_user()
    if not current:
        return
    follower_id = current["id"]
    target_user_id = data.get("targetUserId")
    if not target_user_id or int(target_user_id) == follower_id:
        return

    db = get_db()
    target = db.execute("SELECT is_private FROM users WHERE id = ?", (target_user_id,)).fetchone()
    status = "pending" if target and target["is_private"] else "accepted"
    try:
        existing = db.execute(
            "SELECT id FROM follows WHERE follower_id = ? AND target_user_id = ?",
            (follower_id, target_user_id)
        ).fetchone()
        if existing:
            db.execute("DELETE FROM follows WHERE id = ?", (existing["id"],))
            is_following = False
            status = None
        else:
            db.execute(
                "INSERT INTO follows (follower_id, target_user_id, status) VALUES (?, ?, ?)",
                (follower_id, target_user_id, status)
            )
            is_following = status == "accepted"
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        existing = db.execute(
            "SELECT id, status FROM follows WHERE follower_id = ? AND target_user_id = ?",
            (follower_id, target_user_id)
        ).fetchone()
        is_following = bool(existing and existing["status"] == "accepted")
        status = existing["status"] if existing else None
        db.commit()
    db.close()
    emit("follow_status", {
        "targetUserId": target_user_id,
        "isFollowing": is_following,
        "status": status
    })


@socketio.on("call_signal")
def handle_call_signal(data):
    """WebRTC signaling relay for audio/video calls."""
    current = get_current_user()
    if not current:
        return
    target = data.get("targetUsername")
    if target:
        emit("call_signal", {
            "from": current["username"],
            "signal": data.get("signal"),
            "callType": data.get("callType", "audio")
        }, room=f"user_{target.lower()}")


@socketio.on("call_response")
def handle_call_response(data):
    current = get_current_user()
    if not current:
        return
    target = data.get("targetUsername")
    if target:
        emit("call_response", {
            "from": current["username"],
            "accepted": data.get("accepted", False),
            "callId": data.get("callId")
        }, room=f"user_{target.lower()}")


@socketio.on("join_live")
def join_live(data):
    live_id = data.get("liveId")
    if live_id:
        join_room(f"live_{live_id}")
        db = get_db()
        db.execute("UPDATE live_sessions SET viewer_count = viewer_count + 1 WHERE id = ?", (live_id,))
        db.commit()
        row = db.execute("SELECT viewer_count FROM live_sessions WHERE id = ?", (live_id,)).fetchone()
        db.close()
        emit("live_viewers", {"liveId": live_id, "count": row["viewer_count"] if row else 0}, room=f"live_{live_id}")


@socketio.on("live_chat")
def live_chat(data):
    current = get_current_user()
    if not current:
        return
    live_id = data.get("liveId")
    text = (data.get("text") or "").strip()
    if live_id and text:
        emit("live_chat_message", {
            "username": current["username"],
            "text": text,
            "avatar": current["avatar"]
        }, room=f"live_{live_id}")



# ============================================================
# PREMIUM / STRIPE PAYMENTS
# Money lands in YOUR Stripe account (configure STRIPE_SECRET_KEY)
# ============================================================

def _stripe_ready():
    return bool(stripe and STRIPE_SECRET_KEY)


def _activate_premium(user_id, plan_id, stripe_customer_id="", stripe_subscription_id="", stripe_session_id="", period_end=None):
    """Mark user as premium and record subscription."""
    db = get_db()
    if not period_end:
        days = 365 if plan_id == "yearly" else 31
        period_end = (datetime.now(timezone.utc) + timedelta(days=days)).isoformat()
    elif isinstance(period_end, (int, float)):
        period_end = datetime.fromtimestamp(period_end, tz=timezone.utc).isoformat()

    db.execute(
        "UPDATE users SET is_premium = 1, premium_until = ?, stripe_customer_id = COALESCE(NULLIF(?, ''), stripe_customer_id) WHERE id = ?",
        (period_end, stripe_customer_id or "", user_id)
    )
    # upsert subscription row
    existing = db.execute(
        "SELECT id FROM subscriptions WHERE user_id = ? AND status IN ('active', 'pending') ORDER BY id DESC LIMIT 1",
        (user_id,)
    ).fetchone()
    ts = now()
    if existing:
        db.execute(
            """UPDATE subscriptions SET plan_id=?, stripe_customer_id=?, stripe_subscription_id=?,
               stripe_session_id=?, status='active', current_period_end=?, updated_at=? WHERE id=?""",
            (plan_id, stripe_customer_id or "", stripe_subscription_id or "",
             stripe_session_id or "", period_end, ts, existing["id"])
        )
    else:
        db.execute(
            """INSERT INTO subscriptions
               (user_id, plan_id, stripe_customer_id, stripe_subscription_id, stripe_session_id,
                status, current_period_end, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, 'active', ?, ?, ?)""",
            (user_id, plan_id, stripe_customer_id or "", stripe_subscription_id or "",
             stripe_session_id or "", period_end, ts, ts)
        )
    db.commit()
    db.close()
    return period_end


@app.route("/api/premium/plans", methods=["GET"])
def premium_plans():
    """List available premium plans + current user status."""
    user = get_current_user()
    plans = []
    for key, plan in PREMIUM_PLANS.items():
        plans.append({
            **plan,
            "price_display": f"${plan['price_cents'] / 100:.2f}",
            "stripe_price_id": STRIPE_PRICE_MONTHLY if key == "monthly" else STRIPE_PRICE_YEARLY,
        })
    payload = {
        "success": True,
        "plans": plans,
        "stripe_configured": _stripe_ready(),
        "publishable_key": STRIPE_PUBLISHABLE_KEY or None,
        "currency": "usd",
    }
    if user:
        payload["user"] = {
            "isPremium": is_user_premium(user),
            "premiumUntil": (user["premium_until"] if "premium_until" in user.keys() else None),
        }
    return jsonify(payload)


@app.route("/api/premium/checkout", methods=["POST"])
def premium_checkout():
    """Create Stripe Checkout Session — payment goes to your Stripe account."""
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401
    if not _stripe_ready():
        return jsonify({
            "success": False,
            "message": "Stripe haijasetiwa. Weka STRIPE_SECRET_KEY kwenye environment."
        }), 503

    data = request.get_json(silent=True) or {}
    plan_id = str(data.get("plan", "monthly")).lower()
    if plan_id not in PREMIUM_PLANS:
        return jsonify({"success": False, "message": "Invalid plan"}), 400

    plan = PREMIUM_PLANS[plan_id]
    price_id = STRIPE_PRICE_MONTHLY if plan_id == "monthly" else STRIPE_PRICE_YEARLY

    # Reuse or create Stripe customer
    customer_id = ""
    try:
        customer_id = user["stripe_customer_id"] if "stripe_customer_id" in user.keys() else ""
    except Exception:
        customer_id = ""
    if not customer_id:
        try:
            customer = stripe.Customer.create(
                email=user["email"] or None,
                name=user["username"],
                metadata={"telapp_user_id": str(user["id"])},
            )
            customer_id = customer.id
            db = get_db()
            db.execute("UPDATE users SET stripe_customer_id = ? WHERE id = ?", (customer_id, user["id"]))
            db.commit()
            db.close()
        except Exception as e:
            return jsonify({"success": False, "message": f"Stripe customer error: {e}"}), 500

    success_url = f"{APP_BASE_URL}/?premium=success&session_id={{CHECKOUT_SESSION_ID}}"
    cancel_url = f"{APP_BASE_URL}/?premium=cancel"

    line_items = []
    if price_id:
        line_items = [{"price": price_id, "quantity": 1}]
    else:
        # Inline price so it works without pre-created Price IDs
        line_items = [{
            "price_data": {
                "currency": plan["currency"],
                "unit_amount": plan["price_cents"],
                "recurring": {"interval": plan["interval"]},
                "product_data": {
                    "name": f"TelApp {plan['name']}",
                    "description": plan["description"],
                },
            },
            "quantity": 1,
        }]

    try:
        session_obj = stripe.checkout.Session.create(
            mode="subscription",
            customer=customer_id,
            line_items=line_items,
            success_url=success_url,
            cancel_url=cancel_url,
            client_reference_id=str(user["id"]),
            metadata={
                "telapp_user_id": str(user["id"]),
                "plan_id": plan_id,
            },
            subscription_data={
                "metadata": {
                    "telapp_user_id": str(user["id"]),
                    "plan_id": plan_id,
                }
            },
            allow_promotion_codes=True,
        )
    except Exception as e:
        return jsonify({"success": False, "message": f"Checkout error: {e}"}), 500

    # Record pending subscription
    db = get_db()
    ts = now()
    db.execute(
        """INSERT INTO subscriptions
           (user_id, plan_id, stripe_customer_id, stripe_session_id, status, created_at, updated_at)
           VALUES (?, ?, ?, ?, 'pending', ?, ?)""",
        (user["id"], plan_id, customer_id, session_obj.id, ts, ts)
    )
    db.commit()
    db.close()

    return jsonify({
        "success": True,
        "checkout_url": session_obj.url,
        "session_id": session_obj.id,
    })


@app.route("/api/premium/confirm", methods=["POST"])
def premium_confirm():
    """Confirm a completed Checkout session (fallback if webhook delayed)."""
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401
    if not _stripe_ready():
        return jsonify({"success": False, "message": "Stripe not configured"}), 503

    data = request.get_json(silent=True) or {}
    session_id = str(data.get("session_id", "")).strip()
    if not session_id:
        return jsonify({"success": False, "message": "session_id required"}), 400

    try:
        sess = stripe.checkout.Session.retrieve(session_id, expand=["subscription"])
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 400

    if sess.payment_status not in ("paid", "no_payment_required") and sess.status != "complete":
        return jsonify({"success": False, "message": "Payment not complete", "status": sess.status}), 400

    meta = sess.metadata or {}
    uid = int(meta.get("telapp_user_id") or sess.client_reference_id or 0)
    if uid and uid != user["id"]:
        return jsonify({"success": False, "message": "Session does not belong to this user"}), 403

    plan_id = meta.get("plan_id") or "monthly"
    sub_id = ""
    period_end = None
    if sess.subscription:
        sub = sess.subscription if not isinstance(sess.subscription, str) else stripe.Subscription.retrieve(sess.subscription)
        sub_id = sub.id if hasattr(sub, "id") else str(sess.subscription)
        period_end = getattr(sub, "current_period_end", None)

    until = _activate_premium(
        user["id"], plan_id,
        stripe_customer_id=sess.customer or "",
        stripe_subscription_id=sub_id,
        stripe_session_id=session_id,
        period_end=period_end,
    )
    refreshed = get_current_user()
    return jsonify({
        "success": True,
        "message": "Premium activated!",
        "premiumUntil": until,
        "user": user_dict(refreshed),
    })


@app.route("/api/premium/webhook", methods=["POST"])
def premium_webhook():
    """Stripe webhook — set this URL in Stripe Dashboard → Webhooks.
    Events: checkout.session.completed, customer.subscription.updated/deleted
    """
    if not _stripe_ready():
        return jsonify({"error": "Stripe not configured"}), 503

    payload = request.get_data()
    sig = request.headers.get("Stripe-Signature", "")

    try:
        if STRIPE_WEBHOOK_SECRET:
            event = stripe.Webhook.construct_event(payload, sig, STRIPE_WEBHOOK_SECRET)
        else:
            # Dev mode without signature verification
            event = stripe.Event.construct_from(json.loads(payload), stripe.api_key)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    etype = event["type"]
    obj = event["data"]["object"]

    if etype == "checkout.session.completed":
        meta = obj.get("metadata") or {}
        uid = int(meta.get("telapp_user_id") or obj.get("client_reference_id") or 0)
        plan_id = meta.get("plan_id") or "monthly"
        if uid:
            sub_id = obj.get("subscription") or ""
            period_end = None
            if sub_id:
                try:
                    sub = stripe.Subscription.retrieve(sub_id)
                    period_end = sub.current_period_end
                except Exception:
                    pass
            _activate_premium(
                uid, plan_id,
                stripe_customer_id=obj.get("customer") or "",
                stripe_subscription_id=sub_id if isinstance(sub_id, str) else "",
                stripe_session_id=obj.get("id") or "",
                period_end=period_end,
            )

    elif etype in ("customer.subscription.updated", "customer.subscription.deleted"):
        meta = obj.get("metadata") or {}
        uid = int(meta.get("telapp_user_id") or 0)
        status = obj.get("status", "")
        sub_id = obj.get("id", "")
        period_end = obj.get("current_period_end")
        if uid:
            db = get_db()
            if status in ("active", "trialing"):
                plan_id = meta.get("plan_id") or "monthly"
                until = datetime.fromtimestamp(period_end, tz=timezone.utc).isoformat() if period_end else None
                db.execute(
                    "UPDATE users SET is_premium = 1, premium_until = ? WHERE id = ?",
                    (until or now(), uid)
                )
                db.execute(
                    "UPDATE subscriptions SET status=?, current_period_end=?, updated_at=? WHERE stripe_subscription_id=?",
                    (status, until, now(), sub_id)
                )
            else:
                # canceled / unpaid / incomplete
                db.execute("UPDATE users SET is_premium = 0 WHERE id = ?", (uid,))
                db.execute(
                    "UPDATE subscriptions SET status=?, updated_at=? WHERE stripe_subscription_id=?",
                    (status, now(), sub_id)
                )
            db.commit()
            db.close()

    return jsonify({"received": True})


@app.route("/api/premium/status", methods=["GET"])
def premium_status():
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401
    ud = user_dict(user)
    db = get_db()
    sub = db.execute(
        "SELECT * FROM subscriptions WHERE user_id = ? ORDER BY id DESC LIMIT 1",
        (user["id"],)
    ).fetchone()
    db.close()
    return jsonify({
        "success": True,
        "isPremium": ud["isPremium"],
        "premiumUntil": ud.get("premiumUntil"),
        "subscription": dict(sub) if sub else None,
        "benefits": {
            "noWatermark": ud["isPremium"],
            "maxVideoSeconds": MAX_VIDEO_SECONDS_PREMIUM if ud["isPremium"] else MAX_VIDEO_SECONDS,
            "maxDailyPosts": MAX_DAILY_POSTS_PREMIUM if ud["isPremium"] else MAX_DAILY_POSTS,
            "liveUnlock": ud["isPremium"],
            "premiumBadge": ud["isPremium"],
        },
    })


@app.route("/api/premium/portal", methods=["POST"])
def premium_portal():
    """Open Stripe Customer Billing Portal to manage/cancel subscription."""
    user = require_login()
    if not user:
        return jsonify({"success": False, "message": "Login required"}), 401
    if not _stripe_ready():
        return jsonify({"success": False, "message": "Stripe not configured"}), 503
    try:
        cid = user["stripe_customer_id"] if "stripe_customer_id" in user.keys() else ""
    except Exception:
        cid = ""
    if not cid:
        return jsonify({"success": False, "message": "No Stripe customer yet"}), 400
    try:
        portal = stripe.billing_portal.Session.create(
            customer=cid,
            return_url=f"{APP_BASE_URL}/",
        )
        return jsonify({"success": True, "url": portal.url})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


# ============================================================
# START SERVER
# ============================================================

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000, debug=True, allow_unsafe_werkzeug=True)
