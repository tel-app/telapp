import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  Send, 
  MessageCircle, 
  ExternalLink,
  Smartphone
} from 'lucide-react';
import { PostItem } from '../lib/firebase';

interface ShareModalProps {
  post: PostItem | null;
  isOpen: boolean;
  onClose: () => void;
  onShareCompleted?: (platform: string) => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  post,
  isOpen,
  onClose,
  onShareCompleted
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen || !post) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : 'https://telapp.stream';
  const shareUrl = `${currentUrl}#post-${post.id}`;
  const shareTitle = `Watch @${post.username}'s reel on TelApp: "${post.caption}"`;

  const copyToClipboard = () => {
    navigator.clipboard?.writeText(shareUrl);
    setCopied(true);
    onShareCompleted?.('clipboard');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'TelApp Video Stream',
          text: shareTitle,
          url: shareUrl
        });
        onShareCompleted?.('native');
        onClose();
      } catch (err) {
        // User cancelled or share failed
      }
    } else {
      copyToClipboard();
    }
  };

  const socialTargets = [
    {
      name: 'WhatsApp',
      icon: (
        <div className="w-11 h-11 rounded-full bg-[#25D366]/20 border border-[#25D366]/40 flex items-center justify-center text-[#25D366]">
          <MessageCircle className="w-5 h-5 fill-[#25D366]" />
        </div>
      ),
      url: `https://api.whatsapp.com/send?text=${encodeURIComponent(`${shareTitle} ${shareUrl}`)}`
    },
    {
      name: 'X (Twitter)',
      icon: (
        <div className="w-11 h-11 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white">
          <svg className="w-4 h-4 fill-white" viewBox="0 0 24 24">
            <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
          </svg>
        </div>
      ),
      url: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareTitle)}&url=${encodeURIComponent(shareUrl)}`
    },
    {
      name: 'Telegram',
      icon: (
        <div className="w-11 h-11 rounded-full bg-[#229ED9]/20 border border-[#229ED9]/40 flex items-center justify-center text-[#229ED9]">
          <Send className="w-5 h-5 fill-[#229ED9] -translate-x-0.5" />
        </div>
      ),
      url: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareTitle)}`
    },
    {
      name: 'Facebook',
      icon: (
        <div className="w-11 h-11 rounded-full bg-[#1877F2]/20 border border-[#1877F2]/40 flex items-center justify-center text-[#1877F2]">
          <svg className="w-5 h-5 fill-[#1877F2]" viewBox="0 0 24 24">
            <path d="M9 8H6v4h3v12h5V12h3.642L18 8h-4V6.333C14 5.374 14.5 5 15.6 5H18V0h-3.808C10.595 0 9 1.583 9 4.615V8z"/>
          </svg>
        </div>
      ),
      url: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-fade-in">
      <div className="w-full max-w-md bg-[#16122c] border border-[#a29bfe]/20 rounded-t-[28px] sm:rounded-[28px] p-5 shadow-2xl flex flex-col gap-4">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-[#a29bfe]/15">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-[#6c5ce7]" />
            <h3 className="text-base font-bold text-white">Share to Social Media</h3>
          </div>
          <button 
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#0b0914] border border-[#a29bfe]/15 flex items-center justify-center text-[#8b85b1] hover:text-white gpu-tap"
            aria-label="Close share dialog"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Post Preview Snippet */}
        <div className="flex items-center gap-3 p-3 rounded-2xl bg-[#0b0914] border border-[#a29bfe]/10">
          <img 
            src={post.thumbnailUrl} 
            alt={post.caption} 
            className="w-14 h-14 rounded-xl object-cover flex-shrink-0" 
          />
          <div className="flex flex-col min-w-0">
            <span className="text-xs font-bold text-white truncate">@{post.username}</span>
            <p className="text-[11px] text-[#8b85b1] line-clamp-2">{post.caption}</p>
          </div>
        </div>

        {/* Quick Share Platforms Row */}
        <div>
          <span className="text-[11px] font-semibold text-[#8b85b1] uppercase tracking-wider block mb-2.5">
            Send via External Apps
          </span>
          <div className="grid grid-cols-4 gap-2">
            {socialTargets.map(target => (
              <a
                key={target.name}
                href={target.url}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  onShareCompleted?.(target.name);
                  onClose();
                }}
                className="flex flex-col items-center gap-1.5 p-2 rounded-2xl hover:bg-[#211c42] transition-colors text-center gpu-tap"
              >
                {target.icon}
                <span className="text-[10px] font-medium text-[#e2e0f0]">{target.name}</span>
              </a>
            ))}
          </div>
        </div>

        {/* Native System Share & Copy Link */}
        <div className="flex flex-col gap-2 pt-2 border-t border-[#a29bfe]/15">
          {typeof navigator !== 'undefined' && 'share' in navigator && (
            <button
              onClick={handleNativeShare}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#6c5ce7] to-[#e84393] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-[#6c5ce7]/30 gpu-tap"
            >
              <Smartphone className="w-4 h-4" />
              <span>Open System Share Sheet</span>
            </button>
          )}

          <div className="flex items-center gap-2 p-1.5 rounded-xl bg-[#0b0914] border border-[#a29bfe]/20">
            <span className="text-xs text-[#8b85b1] px-2 truncate flex-1 font-mono">
              {shareUrl}
            </span>
            <button
              onClick={copyToClipboard}
              className="px-3 py-1.5 rounded-lg bg-[#211c42] hover:bg-[#6c5ce7] text-white text-xs font-semibold flex items-center gap-1.5 transition-colors gpu-tap"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-[#2ed573]" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy'}</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
